#!/bin/sh
python /server/run.py
sleep infinity