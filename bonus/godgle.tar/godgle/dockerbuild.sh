#!/bin/sh

docker build -t godgle .