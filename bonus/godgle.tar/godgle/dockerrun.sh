#!/bin/sh

docker run --name godgle -dt -p 1006:80 godgle